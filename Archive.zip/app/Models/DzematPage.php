<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

/**
    * Single-page info about the džemat with rich content and gallery.
    */
class DzematPage extends Model implements HasMedia
{
    use HasFactory, InteractsWithMedia;

    protected $guarded = [];

    protected $casts = [
        'gallery' => 'array',
    ];

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('gallery');
    }
}
