import AppLogoIcon from './app-logo-icon';

export default function AppLogo() {
    return (
        <>
            <img src='/logo-delba.png'/>
        </>
    );
}
